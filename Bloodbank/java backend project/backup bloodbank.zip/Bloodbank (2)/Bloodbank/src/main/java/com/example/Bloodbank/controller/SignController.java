package com.example.Bloodbank.controller;

import com.example.Bloodbank.entity.Sign;
import com.example.Bloodbank.service.SignService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/sign"})
@CrossOrigin
public class SignController {
    private final SignService signService;

    @Autowired
    public SignController(SignService signService) {
        this.signService = signService;
    }

    @GetMapping
    public List<Sign> getAllSigns() {
        return this.signService.getAllSigns();
    }

    @GetMapping({"/email"})
    public Sign getSignByEmail(@PathVariable String email) {
        return this.signService.getSignByEmail(email);
    }

    @PostMapping
    public Sign addSign(@RequestBody Sign sign) {
        return this.signService.addSign(sign);
    }

    @PutMapping({"/{id}"})
    public boolean updateSign(@PathVariable Long id, @RequestBody Sign newSign) {
        return this.signService.updateSign(id, newSign);
    }

    @DeleteMapping({"/{id}"})
    public Sign deleteSign(@PathVariable Long id) {
        return this.signService.deleteSign(id);
    }
}