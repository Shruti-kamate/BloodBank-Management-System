package com.example.Bloodbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
